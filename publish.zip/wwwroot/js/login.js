document.getElementById('microsoftLoginBtn').addEventListener('click', () => {
    window.location.href = '/api/auth/login';
});
